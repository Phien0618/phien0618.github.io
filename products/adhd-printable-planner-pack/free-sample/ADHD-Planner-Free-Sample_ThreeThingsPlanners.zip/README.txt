Free sample from Three Things Planners: 5 pages of the ADHD-Friendly Daily & Weekly Planner (US Letter + A4) and 3 phone wallpapers (1170x2532 and 1080x2400). Free for personal use.
Get the full 40-page pack (both sizes, single-page PDFs included, $6): https://phien0618.github.io/products/adhd-printable-planner-pack
